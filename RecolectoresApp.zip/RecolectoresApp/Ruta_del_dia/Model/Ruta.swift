//
//  Ruta.swift
//  Ruta_del_dia
//
//  Created by Alumno on 24/09/26.
//

import Foundation


struct Recoleccion: Codable, Identifiable {
    var id: Int
    var scheduledDate: String
    var expectedAmount: Double
    var order: Int?
    var status: String
    var receivedAmount: Double?
    var notes: String?
    var donorName: String
    var address: String

    // Texto para mostrar en la app
    var estadoTexto: String {
        if status == "SUCCESSFUL" {
            return "Exitosa"
        } else if status == "FAILED" {
            return "Fallida"
        } else {
            return "Pendiente"
        }
    }
}


struct ResultadoRequest: Codable {
    var collectionId: Int
    var status: String
    var receivedAmount: Double?
    var notes: String?
}

struct ResultadoRespuesta: Codable {
    var id: Int
    var status: String
    var receivedAmount: Double?
    var notes: String?
}
